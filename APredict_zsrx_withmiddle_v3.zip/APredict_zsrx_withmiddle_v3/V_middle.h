/* ==================================================================================
File name  : F2833xBASE_VECTOR_GEN.H                                         
Target     : TMS320F2833x family                         
===================================================================================*/

#ifndef V_middle_H_
#define V_middle_H_
//12��io��ǰ���clearû�ġ�ʸ�����ֺ��ǰ������������ģ�����˵��--0����ôȫ����һ���001���������1
#define U_BASE_0    GpioDataRegs.GPACLEAR.all |=  0x00000AAA;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x00000CCC; //- - -
#define U_BASE_1	GpioDataRegs.GPACLEAR.all |=  0x0000069A;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x00000CC6;	//0 - -
#define U_BASE_2	GpioDataRegs.GPACLEAR.all |=  0x00000659;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x00000CC3;	//- - +
#define U_BASE_3	GpioDataRegs.GPACLEAR.all |=  0x00000A69;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x00000C6C;	//- 0 -
#define U_BASE_4	GpioDataRegs.GPACLEAR.all |=  0x00000965;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x00000C66;	//- 0 0
#define U_BASE_5	GpioDataRegs.GPACLEAR.all |=  0x000009A6;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x00000C63;	//- 0 +
#define U_BASE_6    GpioDataRegs.GPACLEAR.all |=  0x00000596;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x00000C3C; //- + -
#define U_BASE_7    GpioDataRegs.GPACLEAR.all |=  0x00000555;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x00000C36; //- + 0
#define U_BASE_8    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x00000C33; //- + +
#define U_BASE_9    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x000006CC; //0 - -
#define U_BASE_10    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000006C6; //0 - 0
#define U_BASE_11    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000006C3; //0 - +
#define U_BASE_12    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x0000066C; //0 0 -
#define U_BASE_13    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000666; //0 0 0
#define U_BASE_14    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000663; //0 0 +
#define U_BASE_15    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x0000063C; //0 + -
#define U_BASE_16    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000636; //0 + 0
#define U_BASE_17    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000633; //0 + +
#define U_BASE_18    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000003CC; //+ - -
#define U_BASE_19    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000003C6; //+ - 0
#define U_BASE_20    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000003C3; //+ - +
#define U_BASE_21    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x0000036C; //+ 0 -
#define U_BASE_22    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000366; //+ 0 0
#define U_BASE_23    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000363; //+ 0 +
#define U_BASE_24    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x0000033C; //+ + -
#define U_BASE_25    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000336; //+ + 0
#define U_BASE_26    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000333; //+ + +



//�е��λ
#define dum0 = 0;//- - -
#define dum1 = 1;//0 - -
#define dum2 = 0;//- - +
#define dum3 = 1;//- 0 -
#define dum4 = -1;//- 0 0
#define dum5 = 0;//- 0 +
#define dum6 = 0;//- + -
#define dum7 = 0;//- + 0
#define dum8 = 0;//- + +
#define dum9 = 1;//0 - -
#define dum10 = -1;//0 - 0
#define dum11 = 0;//0 - +
#define dum12 = -1;//0 0 -
#define dum13 = 0;//0 0 0
#define dum14 = -1;//0 0 +
#define dum15 = 0;//0 + -
#define dum16 = -1;//0 + 0
#define dum17 = 1;//0 + +
#define dum18 = 0;//+ - -
#define dum19 = 0;//+ - 0
#define dum20 = 0;//+ - +
#define dum21 = 0;//+ 0 -
#define dum22 = -1;//+ 0 0
#define dum23 = 1;//+ 0 +
#define dum24 = 0;//+ + -
#define dum25 = 1;//+ + 0
#define dum26 = 0;//+ + +




#endif  // F28379D_BASE_VECTOR_GEN_H_

