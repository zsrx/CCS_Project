/* ==================================================================================
File name  : F2833xBASE_VECTOR_GEN.H                                         
Target     : TMS320F2833x family                         
===================================================================================*/

#ifndef F28379D_BASE_VECTOR_GEN_H_
#define F28379D_BASE_VECTOR_GEN_H_
//12��io��ǰ���clearû�ġ�ʸ�����ֺ��ǰ������������ģ�����˵��--0����ôȫ����һ���001���������1
#define U_BASE_0    GpioDataRegs.GPACLEAR.all |=  0x00000555;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x00000AAA; //- - -
#define U_BASE_1	GpioDataRegs.GPACLEAR.all |=  0x00000559;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x00000AA6;	//0 - -
#define U_BASE_2	GpioDataRegs.GPACLEAR.all |=  0x00000A55;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x000005AA;	//- - +
#define U_BASE_3	GpioDataRegs.GPACLEAR.all |=  0x00000595;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x00000A6A;	//- 0 -
#define U_BASE_4	GpioDataRegs.GPACLEAR.all |=  0x00000995;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x0000066A;	//- 0 0
#define U_BASE_5	GpioDataRegs.GPACLEAR.all |=  0x00000A95;	DELAY_US(5);	GpioDataRegs.GPASET.all |=  0x0000056A;	//- 0 +
#define U_BASE_6    GpioDataRegs.GPACLEAR.all |=  0x000005A5;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x00000A5A; //- + -
#define U_BASE_7    GpioDataRegs.GPACLEAR.all |=  0x000009A5;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x0000065A; //- + 0
#define U_BASE_8    GpioDataRegs.GPACLEAR.all |=  0x00000AA5;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x0000055A; //- + +
#define U_BASE_9    GpioDataRegs.GPACLEAR.all |=  0x00000559;   DELAY_US(5);    GpioDataRegs.GPASET.all |=  0x00000AA6; //0 - -
#define U_BASE_10    GpioDataRegs.GPACLEAR.all |=  0x00000959;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000006A6; //0 - 0
#define U_BASE_11    GpioDataRegs.GPACLEAR.all |=  0x00000A59;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000005A6; //0 - +
#define U_BASE_12    GpioDataRegs.GPACLEAR.all |=  0x00000599;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000A66; //0 0 -
#define U_BASE_13    GpioDataRegs.GPACLEAR.all |=  0x00000999;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000666; //0 0 0
#define U_BASE_14    GpioDataRegs.GPACLEAR.all |=  0x00000A99;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000566; //0 0 +
#define U_BASE_15    GpioDataRegs.GPACLEAR.all |=  0x000005A9;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000A56; //0 + -
#define U_BASE_16    GpioDataRegs.GPACLEAR.all |=  0x000009A9;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000656; //0 + 0
#define U_BASE_17    GpioDataRegs.GPACLEAR.all |=  0x00000AA9;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000556; //0 + +
#define U_BASE_18    GpioDataRegs.GPACLEAR.all |=  0x0000055A;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000AA5; //+ - -
#define U_BASE_19    GpioDataRegs.GPACLEAR.all |=  0x0000095A;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000006A5; //+ - 0
#define U_BASE_20    GpioDataRegs.GPACLEAR.all |=  0x00000A5A;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x000005A5; //+ - +
#define U_BASE_21    GpioDataRegs.GPACLEAR.all |=  0x0000059A;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000A65; //+ 0 -
#define U_BASE_22    GpioDataRegs.GPACLEAR.all |=  0x0000099A;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000665; //+ 0 0
#define U_BASE_23    GpioDataRegs.GPACLEAR.all |=  0x00000A9A;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000565; //+ 0 +
#define U_BASE_24    GpioDataRegs.GPACLEAR.all |=  0x000005AA;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000A55; //+ + -
#define U_BASE_25    GpioDataRegs.GPACLEAR.all |=  0x000009AA;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000655; //+ + 0
#define U_BASE_26    GpioDataRegs.GPACLEAR.all |=  0x00000AAA;   DELAY_US(5);   GpioDataRegs.GPASET.all |=  0x00000555; //+ + +



//�е��λ
#define dum0  0;//- - -
#define dum1  1;//0 - -
#define dum2  0;//- - +
#define dum3  1;//- 0 -
#define dum4  -1;//- 0 0
#define dum5  0;//- 0 +
#define dum6  0;//- + -
#define dum7  0;//- + 0
#define dum8  0;//- + +
#define dum9  1;//0 - -
#define dum10  -1;//0 - 0
#define dum11  0;//0 - +
#define dum12  -1;//0 0 -
#define dum13  0;//0 0 0
#define dum14  -1;//0 0 +
#define dum15  0;//0 + -
#define dum16  -1;//0 + 0
#define dum17  1;//0 + +
#define dum18  0;//+ - -
#define dum19  0;//+ - 0
#define dum20  0;//+ - +
#define dum21  0;//+ 0 -
#define dum22  -1;//+ 0 0
#define dum23  1;//+ 0 +
#define dum24  0;//+ + -
#define dum25  1;//+ + 0
#define dum26  0;//+ + +




#endif  // F28379D_BASE_VECTOR_GEN_H_

