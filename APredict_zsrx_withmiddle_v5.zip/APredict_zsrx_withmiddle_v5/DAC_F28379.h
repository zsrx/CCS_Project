/*
 * DAC_F28379.h
 *
 *  Created on: 2020��11��26��
 *      Author: Administrator
 */

#ifndef DAC_F28379_H_
#define DAC_F28379_H_

/*-----------------------------------------------------------------------------
Define the structure of the DAC Object
-----------------------------------------------------------------------------*/
typedef struct {
                _iq ch1;        //input data for channel1   data type Global IQ
                _iq ch2;        //input data for channel2   data type Global IQ
                _iq ch3;        //input data for channel3   data type Global IQ
                _iq ch4;        //input data for channel4   data type Global IQ
                void (*init)();       // Pointer to the init function
                void (*update)();     // Pointer to the read function
    } DACSHOW;
typedef DACSHOW *DACSHOW_handle;

/*-----------------------------------------------------------------------------
 Note 1 : It is necessary to call the init function to change the SPI
            register settings, for the change in the channel setting for
            ChSelect setting changes to take effect.
            The read function will not detect or act upon this change.
-----------------------------------------------------------------------------*/
// Default Initializer for the DACSHOW Object
#define F2837X_DACSHOW_DEFAULTS { 0,             \
                                  0,             \
                                  0,             \
                                  0,             \
                                 (void (*)(Uint32))F2837X_dacshow_init, \
                                 (void (*)(Uint32))F2837X_dacshow_update  \
                               }
#define DACSHOW_DEFAULTS    F2837X_DACSHOW_DEFAULTS
/*------------------------------------------------------------------------------
 Prototypes for the functions in F281XILEG_VDC.C
------------------------------------------------------------------------------*/
void F2837X_dacshow_init(DACSHOW *);
void F2837X_dacshow_update(DACSHOW *);
Uint16  temp;
void F2837X_dacshow_init(DACSHOW *p)
{
    SpiaRegs.SPICCR.bit.SPISWRESET = 0;  //SPI��λ�������ڵ�һ����

    ClkCfgRegs.LOSPCP.bit.LSPCLKDIV = 0;//����Ϊ����ģʽ



    SpiaRegs.SPICCR.all=0x000F;              // SPI��λ������ʱ��Ϊ�����أ�16λ�ַ�����

    SpiaRegs.SPICCR.bit.HS_MODE = 0x1;  //����Ϊ����ģʽ

    SpiaRegs.SPICCR.bit.SPILBK = 0x1;  //loopbackģʽʹ�ܣ���Ӧԭ�����9F��

    SpiaRegs.SPICTL.all=0x000E;              // ʹ����ģʽ����׼��λ��ʹ��TALK��SPIINT����

    SpiaRegs.SPIBRR.all = 0x4;              //���ò�����

//    SpiaRegs.SPIBRR.all = 0x0004;            // ���ò�����
//    SpiaRegs.SPICCR.all =0x009F;             //ʹSPI�˳���λ״̬ ������Ҫ���ظ��ı�Ĵ�����
    SpiaRegs.SPIPRI.bit.FREE = 1;            //����Ϊ��������ģʽ

    SpiaRegs.SPICCR.bit.SPISWRESET=1;        // Enable SPI
}

void F2837X_dacshow_update(DACSHOW *p)
{

//  Uint16  out1=0, out2=0, out3=0, out4=0;
/*------------------------------------------------------------------------------
    //SPI output for 4 channels, the date for DAC7714
    //code formate for DAC7714
    //  A1  A0  X   X   D11 D10 D9  ~   D3  D2  D1  D0
    // address  ignore  MSB                         LSB
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
The input is in [pu], so ch1~ch4 is in the range [- 1.0, +1.0]
Convert the IQ value in the range [- 1.0, +1.0] to a DAC value with the range [ 0 to 4095]:
with the function IQNmpyI32int :
multiplies an IQ number with a long integer and returns the integer part of the result.
------------------------------------------------------------------------------*/
/*
    out1 = _IQmpyI32int(p->ch1,2047);       //Convert CHANNEL1
    out1 += 2047;
    out1 = out1|0x0000;

    out2 = _IQmpyI32int(p->ch2,2047);       //Convert CHANNEL2
    out2 += 2047;
    out2 = out2|0x4000;

    out3 = _IQmpyI32int(p->ch3,2047);       //Convert CHANNEL3
    out3 += 2047;
    out3 = out3|0x8000;

    out4 = _IQmpyI32int(p->ch4,2047);       //Convert CHANNEL4
    out4 += 2047;
    out4 = out4|0xC000;
*/

/*------------------------------------------------------------------------------
Sent data for channel 1
------------------------------------------------------------------------------*/
    SpiaRegs.SPITXBUF = (_IQmpyI32int(p->ch1,2047)+2047)|0x0000;
    while(SpiaRegs.SPISTS.bit.INT_FLAG == 0) {}
    DELAY_US(0.01);      //for(temp=0; temp<2;temp++) {}
    temp = SpiaRegs.SPIRXBUF;
    GpioDataRegs.GPBCLEAR.bit.GPIO61 = 1;      //Enable the LOADDACS pin for DAC7714
    DELAY_US(0.05);      //for(iii=0;iii<10;iii++){}   for T_LDDW>=45ns
    temp = 0;
    GpioDataRegs.GPBSET.bit.GPIO61 = 1;     //Disable the LOADDACS pin for DAC7714
    DELAY_US(0.01);     //for(temp=0; temp<2;temp++) {}
/*------------------------------------------------------------------------------
Sent data for channel 2
------------------------------------------------------------------------------*/
    SpiaRegs.SPITXBUF = (_IQmpyI32int(p->ch2,2047)+2047)|0x4000;
    while(SpiaRegs.SPISTS.bit.INT_FLAG == 0) {}
    DELAY_US(0.01);      //for(temp=0; temp<2;temp++) {}
    temp = SpiaRegs.SPIRXBUF;
    GpioDataRegs.GPBCLEAR.bit.GPIO61 = 1;      //Enable the LOADDACS pin for DAC7714
    DELAY_US(0.05);      //for(iii=0;iii<10;iii++){}
    temp = 0;
    GpioDataRegs.GPBSET.bit.GPIO61 = 1;     //Disable the LOADDACS pin for DAC7714
    DELAY_US(0.01);     //for(temp=0; temp<2;temp++) {}
/*------------------------------------------------------------------------------
Sent data for channel 3
------------------------------------------------------------------------------*/
    SpiaRegs.SPITXBUF = (_IQmpyI32int(p->ch3,2047)+2047)|0x8000;
    while(SpiaRegs.SPISTS.bit.INT_FLAG == 0) {}
    DELAY_US(0.01);      //for(temp=0; temp<2;temp++) {}
    temp = SpiaRegs.SPIRXBUF;
    GpioDataRegs.GPBCLEAR.bit.GPIO61 = 1;      //Enable the LOADDACS pin for DAC7714
    DELAY_US(0.05);    //for(iii=0;iii<10;iii++){}
    temp = 0;
    GpioDataRegs.GPBSET.bit.GPIO61 = 1;      //Disable the LOADDACS pin for DAC7714
    DELAY_US(0.01);     //for(temp=0; temp<2;temp++) {}
/*------------------------------------------------------------------------------
Sent data for channel 4
------------------------------------------------------------------------------*/
    SpiaRegs.SPITXBUF = (_IQmpyI32int(p->ch4,2047)+2047)|0xC000;
    while(SpiaRegs.SPISTS.bit.INT_FLAG == 0) {}
    DELAY_US(0.01);      //for(temp=0; temp<2;temp++) {}
    temp = SpiaRegs.SPIRXBUF;
    GpioDataRegs.GPBCLEAR.bit.GPIO61 = 1;      //Enable the LOADDACS pin for DAC7714
    DELAY_US(0.05);    //for(iii=0;iii<10;iii++){}
    temp = 0;
    GpioDataRegs.GPBSET.bit.GPIO61 = 1;      //Disable the LOADDACS pin for DAC7714
    DELAY_US(0.01);     //for(temp=0; temp<2;temp++) {}
}




#endif /* DAC_F28379_H_ */
